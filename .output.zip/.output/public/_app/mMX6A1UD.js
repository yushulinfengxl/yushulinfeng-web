import{c as e,o as t}from"./VtH-_z-d.js";const o={id:"main"},a={__name:"immersive",setup(c){return(r,s)=>(t(),e("div",o))}};export{a as default};
