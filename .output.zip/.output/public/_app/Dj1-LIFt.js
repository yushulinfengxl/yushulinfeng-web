import{_ as e}from"./DlAUqK2U.js";import{c,o as r}from"./VtH-_z-d.js";const o={};function t(n,a){return r(),c("div",null," Search ")}const f=e(o,[["render",t]]);export{f as default};
