import{_ as e}from"./DlAUqK2U.js";import{c as o,o as t}from"./VtH-_z-d.js";const c={},r={id:"main"};function n(_,s){return t(),o("div",r)}const i=e(c,[["render",n]]);export{i as default};
