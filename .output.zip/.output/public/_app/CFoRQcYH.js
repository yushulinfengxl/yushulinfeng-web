import{_ as e}from"./DlAUqK2U.js";import{c as t,o as c}from"./VtH-_z-d.js";const o={};function r(n,s){return c(),t("div",null," test ")}const f=e(o,[["render",r]]);export{f as default};
