import{_ as o}from"./DlAUqK2U.js";import{c as e,o as t}from"./VtH-_z-d.js";const c={};function r(n,a){return t(),e("div",null," about ")}const f=o(c,[["render",r]]);export{f as default};
