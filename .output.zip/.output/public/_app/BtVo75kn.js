import{_ as e}from"./DlAUqK2U.js";import{c as o,o as c}from"./VtH-_z-d.js";const t={},r={class:"home"};function s(n,_){return c(),o("div",r," Home ")}const f=e(t,[["render",s]]);export{f as default};
