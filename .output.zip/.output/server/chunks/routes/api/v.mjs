import { c as defineEventHandler, u as useRuntimeConfig } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';
import 'node:path';

const v = defineEventHandler((event) => {
  const config = useRuntimeConfig();
  return {
    version: config.public.version
  };
});

export { v as default };
//# sourceMappingURL=v.mjs.map
